const API_BASE_URL = "https://fastapi-example-lcbc.onrender.com";

const statusEl = document.getElementById("status");
const checkBtn = document.getElementById("check");

async function checkBackend() {
  statusEl.textContent = "Checking connection…";
  statusEl.className = "";

  try {
    const response = await fetch(`${API_BASE_URL}/`, {
      method: "GET",
      headers: { "Accept": "application/json" }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    let message = "Backend connected successfully.";
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await response.json();
      if (data.message) message = `Connected: ${data.message}`;
    }

    statusEl.textContent = message;
    statusEl.className = "ok";
  } catch (error) {
    console.error("Tesfa backend connection error:", error);
    statusEl.textContent = "Could not connect to the Tesfa backend.";
    statusEl.className = "bad";
  }
}

checkBtn.addEventListener("click", checkBackend);
window.addEventListener("DOMContentLoaded", checkBackend);
